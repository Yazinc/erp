<?php  include("../../classes/class_db.php"); ?>

  <form action="<?php echo $_SERVER['SELF']?>" method="post" id="new_account">
<div class="form-group">
      <div>
        <label for="title">Account Name:</label>
        <input name="title" type="text" class="form-control">
      </div>
      <div>
        <label for="sub_account_id">Sub account of:</label>
        <select name="sub_account_id" class="form-control">
          
          <?PHP //starting from here
	$catmap = new dbs();
		$categoryList = $catmap->cata_map();
		//$categoryList = categoryParentChildTree(); 
		foreach($categoryList as $key => $value){
			echo '<option value='.$value['account_id'].'>'.$value['title'].'</option>';
			//echo $value['->'].$value['title'].'<br>';
		}
		
	?>
        </select>
      </div>
      <div>
        <label for="account_type_id">Select Account Type:</label>
        <select name="account_type_id" class="form-control">
          <option value="1" selected="selected">Vendor</option>
          <option value="2">Customer</option>
          </select>
      </div>
      <div>
        <label for="description">Description:</label>
        <textarea name="description"></textarea>
      </div>
      
      <div>
        
        <label for="terms_id">Terms:</label>
        <select name="terms_id" class="form-control">
          <?php 
		$terms = new dbs();
		$terms->paraterms();
		?>
        </select>
        
        <label for="employee_id">REP:</label>
        <select name="employee_id" class="form-control">
          <option value="1" selected="selected">Admin</option>
          <option value="2">Accounts</option>
        </select>
      </div>
<div>
      <label for="date">Reg. Date:</label>
        <input name="reg_date" type="date" class="form-control" value="02/10/2017">
      </div>
      <div>
        <div>
          <label for="employee_id">REP:</label>
          <select name="employee_id" class="form-control">
            <option value="1" selected="selected">Admin</option>
            <option value="2">Accounts</option>
          </select>
        </div>
        
        <label for="order_3">Order:</label>
        <select name="order_" class="form-control">
          <option value="1" selected="selected">Account Names 1</option>
          <option value="2">Account Names 2</option>
        </select>
        
        <label for="active">Active:</label>
        <select name="active" class="form-control">
          <option value="Yes" selected="selected">Yes</option>
          <option value="No">No</option>
        </select>
      </div>
    </p>
    <p>
      <label for="contact_id">CONTACT:</label>
      <select name="contact_id" id="contact_id">
        <option value="1" selected="selected">Contact one</option>
        <option value="2">contact two</option>
      </select>
      <br>
      <input type="submit" name="submit" id="submit" value="Submit">
    </p>
  </div>
  </form>


<?php 

$new_acct = new dbs;
$new_acct->db_connect();


echo $_POST['desc']; 

$sql= "INSERT INTO accounts(
sub_account_id,
account_type_id,
title,
description,
terms_id,
contact_id,
reg_date,
active,
order_
) VALUES (
'$_POST[sub_account_id]',
'$_POST[account_type_id]',
'$_POST[title]',
'$_POST[description]',
'$_POST[terms_id]',
'$_POST[contact_id]',
'$_POST[reg_date]',
'$_POST[active]',
'$_POST[order_]'
)";





if($new_acct ->mysqli->query($sql) === true){
echo "Good Job. Records inserted successfully.";
} else{
echo "ERROR: Could not able to execute $sql. " . $mysqli->error;

}
// Close connection

$new_acct->mysqli->close();

?>

