<a href="new.php">Enter New</a><br>
<?php  include("../../classes/class_db.php"); ?>

<?php 
	
		$catmap = new dbs();
		$categoryList = $catmap->cata_map();
		//$categoryList = categoryParentChildTree(); 
		foreach($categoryList as $key => $value){
			echo $value['->'].$value['title'].'<br>';
		}
	
	?>