Rename Table:
 SQL query 
 RENAME TABLE account_sys TO trans;