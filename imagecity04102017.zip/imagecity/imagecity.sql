-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.35 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5174
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table imagecity.accounts
CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `terms_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `reg_date` date DEFAULT NULL,
  `active` varchar(50) DEFAULT '0',
  `order_` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `sub_vendor_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 COMMENT='Containg Vendor Information Status';

-- Dumping data for table imagecity.accounts: ~3 rows (approximately)
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` (`account_id`, `parent_id`, `account_type_id`, `title`, `description`, `terms_id`, `contact_id`, `reg_date`, `active`, `order_`, `employee_id`) VALUES
	(1, 0, 3, 'Fototrade', 'Saeed', NULL, 1, '2017-10-01', 'Yes', 1, 1),
	(2, 1, 3, 'Khawaja Fotos', 'Faraz', NULL, 2, '2017-10-03', 'Yes', 1, 1),
	(3, 2, 3, 'MBM', 'Wajahat', NULL, 3, '2014-10-04', 'Yes', 1, 1);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;

-- Dumping structure for table imagecity.para_account_type
CREATE TABLE IF NOT EXISTS `para_account_type` (
  `account_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type` varchar(100) DEFAULT NULL,
  `memo` varchar(100) DEFAULT NULL,
  `active` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`account_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table imagecity.para_account_type: ~4 rows (approximately)
/*!40000 ALTER TABLE `para_account_type` DISABLE KEYS */;
INSERT INTO `para_account_type` (`account_type_id`, `account_type`, `memo`, `active`) VALUES
	(1, 'Inventory', 'Inventory', 'Yes'),
	(2, 'RA', 'Customer', 'Yes'),
	(3, 'PA', 'Vendor', 'Yes'),
	(4, 'Services', 'Services', 'Yes');
/*!40000 ALTER TABLE `para_account_type` ENABLE KEYS */;

-- Dumping structure for table imagecity.para_stock_trans_type
CREATE TABLE IF NOT EXISTS `para_stock_trans_type` (
  `stock_trans_type` varchar(100) DEFAULT NULL,
  `stock_trans_type_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`stock_trans_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table imagecity.para_stock_trans_type: ~4 rows (approximately)
/*!40000 ALTER TABLE `para_stock_trans_type` DISABLE KEYS */;
INSERT INTO `para_stock_trans_type` (`stock_trans_type`, `stock_trans_type_id`) VALUES
	('Bill', 1),
	('Invoice', 2),
	('Credit Memos', 3),
	('Item Returned', 4);
/*!40000 ALTER TABLE `para_stock_trans_type` ENABLE KEYS */;

-- Dumping structure for table imagecity.para_terms
CREATE TABLE IF NOT EXISTS `para_terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `terms` varchar(100) DEFAULT NULL,
  `active` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table imagecity.para_terms: ~3 rows (approximately)
/*!40000 ALTER TABLE `para_terms` DISABLE KEYS */;
INSERT INTO `para_terms` (`term_id`, `terms`, `active`) VALUES
	(1, '30 Days', 'Yes'),
	(2, '90 Days', 'Yes'),
	(3, 'Due on Receipt', 'No');
/*!40000 ALTER TABLE `para_terms` ENABLE KEYS */;

-- Dumping structure for table imagecity.products
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_product_id` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `desc_pur` varchar(255) DEFAULT NULL,
  `desc_sale` varchar(100) DEFAULT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT '0',
  `sale_price` int(11) DEFAULT '0',
  `po_qty` int(11) DEFAULT '0',
  `so_qty` int(11) DEFAULT '0',
  `reorder_point` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table imagecity.products: ~2 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`product_id`, `sub_product_id`, `name`, `code`, `desc_pur`, `desc_sale`, `account_type_id`, `cost`, `sale_price`, `po_qty`, `so_qty`, `reorder_point`, `type_id`) VALUES
	(1, 0, 'FZ2600', '12336', 'Nothing', 'Nothing', 1, 5000, 9000, 0, 0, 2, 1),
	(2, 0, 'PV100', '12337', 'Digital Camera', 'Test', 1, 3000, 8000, 0, 0, 0, 0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table imagecity.purchase_order
CREATE TABLE IF NOT EXISTS `purchase_order` (
  `po_no` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT '0',
  `date` date DEFAULT '0000-00-00',
  `memo` varchar(255) DEFAULT '0000-00-00',
  PRIMARY KEY (`po_no`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Enter Bills for Receipt Items';

-- Dumping data for table imagecity.purchase_order: ~0 rows (approximately)
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;

-- Dumping structure for table imagecity.stock_trans
CREATE TABLE IF NOT EXISTS `stock_trans` (
  `stock_trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_trans_type_id` int(11) NOT NULL,
  `stock_trans_dt` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty_po` int(11) NOT NULL,
  `qty_so` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  PRIMARY KEY (`stock_trans_id`),
  KEY `product_id` (`product_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `bill_id` (`bill_id`),
  KEY `po_id` (`po_id`),
  KEY `stock_trans_type_id` (`stock_trans_type_id`),
  CONSTRAINT `FK_stock_trans_para_stock_trans_type` FOREIGN KEY (`stock_trans_type_id`) REFERENCES `para_stock_trans_type` (`stock_trans_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table imagecity.stock_trans: ~1 rows (approximately)
/*!40000 ALTER TABLE `stock_trans` DISABLE KEYS */;
INSERT INTO `stock_trans` (`stock_trans_id`, `stock_trans_type_id`, `stock_trans_dt`, `product_id`, `qty_po`, `qty_so`, `qty`, `value`, `account_id`, `po_id`, `invoice_id`, `bill_id`) VALUES
	(1, 1, '2017-10-02', 2, 0, 0, 2, 500, 1, 0, 0, 1);
/*!40000 ALTER TABLE `stock_trans` ENABLE KEYS */;

-- Dumping structure for table imagecity.trans
CREATE TABLE IF NOT EXISTS `trans` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_date` date DEFAULT NULL,
  `account_id` varchar(255) NOT NULL DEFAULT '0',
  `trans_type_id` int(11) NOT NULL DEFAULT '0',
  `debit` int(11) NOT NULL DEFAULT '0',
  `credit` int(11) NOT NULL DEFAULT '0',
  `memo` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Charts of Accounts';

-- Dumping data for table imagecity.trans: ~0 rows (approximately)
/*!40000 ALTER TABLE `trans` DISABLE KEYS */;
/*!40000 ALTER TABLE `trans` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_categories
CREATE TABLE IF NOT EXISTS `virtuemart_categories` (
  `virtuemart_category_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Belongs to vendor',
  `category_template` varchar(128) DEFAULT NULL,
  `category_layout` varchar(64) DEFAULT NULL,
  `category_product_layout` varchar(64) DEFAULT NULL,
  `products_per_row` varchar(1) NOT NULL DEFAULT '',
  `limit_list_step` varchar(32) DEFAULT NULL,
  `limit_list_initial` smallint(1) unsigned DEFAULT NULL,
  `hits` int(1) unsigned NOT NULL DEFAULT '0',
  `cat_params` varchar(15359) NOT NULL DEFAULT '',
  `metarobot` varchar(40) NOT NULL DEFAULT '',
  `metaauthor` varchar(64) NOT NULL DEFAULT '',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_category_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Product Categories are stored here';

-- Dumping data for table imagecity.virtuemart_categories: 0 rows
/*!40000 ALTER TABLE `virtuemart_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_categories` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_category_categories
CREATE TABLE IF NOT EXISTS `virtuemart_category_categories` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `category_parent_id` int(1) unsigned NOT NULL DEFAULT '0',
  `category_child_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_parent_id` (`category_parent_id`,`category_child_id`),
  KEY `category_child_id` (`category_child_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Category child-parent relation list';

-- Dumping data for table imagecity.virtuemart_category_categories: 0 rows
/*!40000 ALTER TABLE `virtuemart_category_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_category_categories` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_category_medias
CREATE TABLE IF NOT EXISTS `virtuemart_category_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_category_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_category_id` (`virtuemart_category_id`,`virtuemart_media_id`),
  KEY `ordering` (`virtuemart_category_id`,`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table imagecity.virtuemart_category_medias: 0 rows
/*!40000 ALTER TABLE `virtuemart_category_medias` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_category_medias` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_manufacturercategories
CREATE TABLE IF NOT EXISTS `virtuemart_manufacturercategories` (
  `virtuemart_manufacturercategories_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_manufacturercategories_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Manufacturers are assigned to these categories';

-- Dumping data for table imagecity.virtuemart_manufacturercategories: 0 rows
/*!40000 ALTER TABLE `virtuemart_manufacturercategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_manufacturercategories` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_manufacturers
CREATE TABLE IF NOT EXISTS `virtuemart_manufacturers` (
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_manufacturercategories_id` int(1) DEFAULT NULL,
  `metarobot` varchar(400) DEFAULT NULL,
  `metaauthor` varchar(400) DEFAULT NULL,
  `hits` int(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_manufacturer_id`),
  UNIQUE KEY `virtuemart_manufacturercategories_id` (`virtuemart_manufacturer_id`,`virtuemart_manufacturercategories_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Manufacturers are those who deliver products';

-- Dumping data for table imagecity.virtuemart_manufacturers: 0 rows
/*!40000 ALTER TABLE `virtuemart_manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_manufacturers` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_manufacturer_medias
CREATE TABLE IF NOT EXISTS `virtuemart_manufacturer_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_manufacturer_id` (`virtuemart_manufacturer_id`,`virtuemart_media_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table imagecity.virtuemart_manufacturer_medias: 0 rows
/*!40000 ALTER TABLE `virtuemart_manufacturer_medias` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_manufacturer_medias` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_products
CREATE TABLE IF NOT EXISTS `virtuemart_products` (
  `product_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `product_parent_id` int(1) unsigned NOT NULL DEFAULT '0',
  `product_sku` varchar(255) DEFAULT NULL,
  `product_gtin` varchar(64) DEFAULT NULL,
  `product_mpn` varchar(64) DEFAULT NULL,
  `product_weight` decimal(10,4) DEFAULT NULL,
  `product_weight_uom` varchar(7) DEFAULT NULL,
  `product_length` decimal(10,4) DEFAULT NULL,
  `product_width` decimal(10,4) DEFAULT NULL,
  `product_height` decimal(10,4) DEFAULT NULL,
  `product_lwh_uom` varchar(7) DEFAULT NULL,
  `product_url` varchar(255) DEFAULT NULL,
  `product_in_stock` int(1) NOT NULL DEFAULT '0',
  `product_ordered` int(1) NOT NULL DEFAULT '0',
  `product_stockhandle` varchar(24) NOT NULL DEFAULT '0',
  `low_stock_notification` int(1) unsigned NOT NULL DEFAULT '0',
  `product_available_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_availability` varchar(32) DEFAULT NULL,
  `product_special` tinyint(1) DEFAULT NULL,
  `product_discontinued` tinyint(1) DEFAULT NULL,
  `product_sales` int(1) unsigned NOT NULL DEFAULT '0',
  `product_unit` varchar(8) DEFAULT NULL,
  `product_packaging` decimal(8,4) unsigned DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `pordering` int(1) unsigned NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `product_parent_id` (`product_parent_id`),
  KEY `product_special` (`product_special`),
  KEY `product_discontinued` (`product_discontinued`),
  KEY `product_in_stock` (`product_in_stock`),
  KEY `product_ordered` (`product_ordered`),
  KEY `published` (`published`),
  KEY `pordering` (`pordering`),
  KEY `created_on` (`created_on`),
  KEY `modified_on` (`modified_on`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='All products are stored here.';

-- Dumping data for table imagecity.virtuemart_products: 1 rows
/*!40000 ALTER TABLE `virtuemart_products` DISABLE KEYS */;
INSERT INTO `virtuemart_products` (`product_id`, `product_parent_id`, `product_sku`, `product_gtin`, `product_mpn`, `product_weight`, `product_weight_uom`, `product_length`, `product_width`, `product_height`, `product_lwh_uom`, `product_url`, `product_in_stock`, `product_ordered`, `product_stockhandle`, `low_stock_notification`, `product_available_date`, `product_availability`, `product_special`, `product_discontinued`, `product_sales`, `product_unit`, `product_packaging`, `published`, `pordering`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES
	(1, 0, '321201', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'www.panasonic.com', 15, 0, '0', 2, '2017-09-21 00:00:00', 'Y', NULL, NULL, 0, NULL, NULL, 1, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0);
/*!40000 ALTER TABLE `virtuemart_products` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_product_categories
CREATE TABLE IF NOT EXISTS `virtuemart_product_categories` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_category_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`product_id`,`virtuemart_category_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Maps Products to Categories';

-- Dumping data for table imagecity.virtuemart_product_categories: 0 rows
/*!40000 ALTER TABLE `virtuemart_product_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_product_categories` ENABLE KEYS */;

-- Dumping structure for table imagecity.virtuemart_product_medias
CREATE TABLE IF NOT EXISTS `virtuemart_product_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_media_id`),
  KEY `virtuemart_media_id` (`virtuemart_media_id`),
  KEY `ordering` (`virtuemart_product_id`,`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table imagecity.virtuemart_product_medias: 0 rows
/*!40000 ALTER TABLE `virtuemart_product_medias` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtuemart_product_medias` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
