 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 


<?php
	class dbs {
	public $mysqli = "";
	function db_connect(){
	$this->mysqli = new mysqli("localhost", "root", "mysql", "imagecity");
	if($this->mysqli === false){
	die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
	//echo "Connect Successfully. Host info: " . $mysqli->host_info;
	}
	
	//Auto Listing
	function para_account_type(){
	$para = new dbs();
	$para->db_connect();
	$sql = "SELECT
	para_account_type.account_type_id,
	para_account_type.account_type
	FROM
	para_account_type
	WHERE
	para_account_type.active LIKE 'Yes'
	ORDER BY
	para_account_type.account_type_id";
	$result = mysqli_query($para->mysqli, $sql);
	foreach ($result as $row){
	echo '<option value='.$row['account_type_id'].'selected="selected">'.$row['account_type'].'</option>';
		//echo $row['account_type']."<br>";
	}
	//return "funcation connected ".$table;
	}

	function para_subaccount(){
	$subaccount = new dbs();
	$subaccount->db_connect();
	$sql =
	"SELECT
	accounts.account_id,
	accounts.title
	FROM
	accounts
	ORDER BY
	accounts.account_id";
	$result = mysqli_query($subaccount->mysqli, $sql);
	foreach ($result as $row){
	echo '<option value='.$row['account_id'].'selected="selected">'.$row['title'].'</option>';
		//echo $row['account_type']."<br>";
	}
	//return "funcation connected ".$table;
	}

function paraterms(){
$paraterm = new dbs();
$paraterm->db_connect();
$sql = 
"SELECT
para_terms.term_id,
para_terms.terms
FROM
para_terms
WHERE
para_terms.active = 'Yes'
ORDER BY
para_terms.term_id";
$result = mysqli_query($paraterm->mysqli, $sql);
foreach ($result as $row){
echo '<option value='.$row['term_id'].'selected="selected">'.$row['terms'].'</option>';	
}
}//end of function




	


	
	

	
	//echo  date('m/d/Y h:i:s a', time());
	//echo date('d/m/Y');


		function cata_map($parent = 0, $spacing = '', $category_tree_array = '') {
		$tree = new dbs();
		$tree->db_connect();
		//global $dbConnection;
		$parent			 =$tree->mysqli->real_escape_string($parent);
		//$parent 		= $dbConnection->real_escape_string($parent);
		if (!is_array($category_tree_array))
		$category_tree_array = array();
		$sql = "SELECT account_id,title,parent_id FROM accounts WHERE parent_id = $parent ORDER BY account_id ASC";
		$resCategory = $tree->mysqli->query($sql);
		//$resCategory=$dbConnection->query($sqlCategory);
		if ($resCategory->num_rows > 0) {
		while($rowCategories = $resCategory->fetch_assoc()) {
		$category_tree_array[] = array("account_id" => $rowCategories['account_id'], "title" => $spacing . $rowCategories['title']);
		$category_tree_array = $this->cata_map($rowCategories['account_id'], '&nbsp;&nbsp;&nbsp;&nbsp;'.$spacing . '-&nbsp;', $category_tree_array);
		}
		}
		return $category_tree_array;
	
}
}//class ends here
?>


 

