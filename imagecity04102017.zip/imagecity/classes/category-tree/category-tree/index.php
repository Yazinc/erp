<?php
	require_once 'db_connection.php';
	require_once 'functions.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Parent Child Category Tree Using PHP & MySQLi</title>
<style type="text/css">
.web{
	font-family:tahoma;
	size:12px;
	top:10%;
	border:1px solid #CDCDCD;
	border-radius:10px;
	padding:10px;
	width:45%;
	margin:auto;
	height:100%;
}
h1{
	margin:3px 0;
	font-size:13px;
	text-decoration:underline;
}
.tLink{
	font-family:tahoma;
	size:12px;
	padding-left:10px;
	text-align:center;
}
.success{
	color:#009900;
}
.error{
	color:#FF0000;
}
.talign_right{
	text-align:right;
}
.username_availability_result{
	display:block;
	width:auto;
	float:left;
	padding-left:10px;
}
.input{
	float:left;
}
</style>
</head>
<body>

<div class='tLink'><strong>Tutorial Link:</strong> <a href='http://www.stepblogging.com/how-to-create-parent-child-category-tree-using-php-mysqli/'target='_blank'>Click Here</a></div><br/>
<div class='web'>
	<h1>Parent Child Category Tree Using PHP & MySQLi</h1> <br />
	<?php 
		$categoryList = categoryParentChildTree(); 
		foreach($categoryList as $key => $value){
			echo $value['name'].'<br>';
		}
	?>
</div>
</body>
</html>
