<?php

class tree extends dbs{
	
		function cata_map($parent = 0, $spacing = '', $category_tree_array = '') {

		$tree = new dbs();
		$tree->db_connect();

		//global $dbConnection;

		$parent			 =$tree->mysqli->real_escape_string($parent);
		//$parent 		= $dbConnection->real_escape_string($parent);
		if (!is_array($category_tree_array))
		$category_tree_array = array();

		$sql = "SELECT account_id,title,parent_id FROM accounts WHERE parent_id = $parent ORDER BY account_id ASC";
		$resCategory = $tree->mysqli->query($sql);
		//$resCategory=$dbConnection->query($sqlCategory);

		if ($resCategory->num_rows > 0) {
		while($rowCategories = $resCategory->fetch_assoc()) {
		$category_tree_array[] = array("account_id" => $rowCategories['account_id'], "title" => $spacing . $rowCategories['title']);
		$category_tree_array = cata_map($rowCategories['account_id'], '&nbsp;&nbsp;&nbsp;&nbsp;'.$spacing . '-&nbsp;', $category_tree_array);
		}
		}
		return $category_tree_array;
	
}

}//end of class