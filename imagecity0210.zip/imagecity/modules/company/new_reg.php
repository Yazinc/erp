<?php  include("../../classes/class_db.php"); ?>
<html>
  <head>
    <meta content="text/html; charset=windows-1252" http-equiv="content-type">
    <style type="text/css">
#title {
  background-color: #ffff99;
  width: auto;
  align-content: flex-start;
  float: left;
  border-radius: 0px;
  border-top-width: 1px;
  border-right-width: 1px;
  border-bottom-width: 1px;
  border-left-width: 1px;
  border-top-style: solid;
  border-right-style: solid;
  border-bottom-style: solid;
  border-left-style: solid;
  width:50%;
}

</style></head>
  <body>
    <h1>Dear Company</h1>
    <p><br>
    </p>
    <p>
      <style type="text/css">
      thead tr {background-color: ActiveCaption; color: CaptionText;}
      th, td {vertical-align: top; font-family: "Tahoma", Arial, Helvetica, sans-serif; font-size: 8pt; padding: 3px; }
      table, td {border: 1px solid silver;}
      table {border-collapse: collapse;}
      thead .col0 {width: 115px;}
      thead .col1 {width: 98px;}
      thead .col2 {width: 53px;}
      thead .col3 {width: 55px;}
      thead .col4 {width: 67px;}
      thead .col5 {width: 110px;}
    </style> </p>
    <table>
      <thead>
        <tr>
          <th class="col0">Field</th>
          <th class="col1">Type</th>
          <th class="col2">Null</th>
          <th class="col3">Key</th>
          <th class="col4">Default</th>
          <th class="col5">Extra</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="col0">company_id</td>
          <td class="col1">int(11)</td>
          <td class="col2">NO</td>
          <td class="col3">PRI</td>
          <td class="col4"><br>
          </td>
          <td class="col5">auto_increment</td>
        </tr>
        <tr>
          <td class="col0">title</td>
          <td class="col1">varchar(255)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">ctc</td>
          <td class="col1">varchar(255)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">email</td>
          <td class="col1">varchar(255)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">role_id</td>
          <td class="col1">int(11)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">reg_date</td>
          <td class="col1">date</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">active</td>
          <td class="col1">int(11)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4">0</td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">sub_company_id</td>
          <td class="col1">int(11)</td>
          <td class="col2">YES</td>
          <td class="col3">MUL</td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
        <tr>
          <td class="col0">order</td>
          <td class="col1">int(11)</td>
          <td class="col2">YES</td>
          <td class="col3"><br>
          </td>
          <td class="col4"><br>
          </td>
          <td class="col5"><br>
          </td>
        </tr>
      </tbody>
    </table>
    &nbsp;<br>
    <div><br>
    </div>
    <br>
  </body>
</html>
